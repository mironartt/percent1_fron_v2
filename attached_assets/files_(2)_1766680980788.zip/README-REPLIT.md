# OnePercent Landing Page - Replit Setup

## 📁 Файлы для загрузки

Загрузи эти файлы в корень проекта Replit:

```
/
├── index.html
├── styles.css
├── script.js
└── README-REPLIT.md (этот файл)
```

## 🚀 Запуск в Replit

### Вариант 1: HTML/CSS/JS Repl
1. Создай новый **HTML, CSS, JS** Repl
2. Замени содержимое `index.html` → скопируй из `index.html`
3. Замени содержимое `style.css` → скопируй из `styles.css`
4. Замени содержимое `script.js` → скопируй из `script.js`
5. Нажми **Run** ▶️

### Вариант 2: Static Website
1. Создай новый **Static Website** Repl
2. Загрузи все 3 файла
3. Нажми **Run** ▶️

## 📝 Структура

**index.html** (основной файл)
- Hero секция
- 8 блоков контента
- Final CTA
- Footer

**styles.css** (стили)
- CSS переменные
- Все компоненты
- Responsive дизайн
- Анимации

**script.js** (интерактив)
- Аккордеоны
- Табы
- Scroll анимации
- Back-to-top кнопка

## 🎨 Особенности

✅ Адаптивный дизайн (320px - 1920px)
✅ Компактные блоки с визуальной иерархией
✅ Transition badges между блоками
✅ Все 6 сфер жизни
✅ Style Guide совместимость

## 🔧 Если что-то не работает

1. Проверь, что все 3 файла в корне проекта
2. Убедись что файлы названы точно: `index.html`, `styles.css`, `script.js`
3. Очисти кеш браузера (Ctrl+Shift+R)

## 📦 Альтернатива: Standalone версия

Если хочешь один файл:
- Используй `index-standalone.html`
- Он содержит всё (HTML + CSS + JS)
- Просто открой в браузере

---

**Готово!** Запускай и наслаждайся 🚀
