// OnePercent Landing Page - JavaScript
// Handles accordions, tabs, smooth scroll, and animations

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // Smooth Scroll for Anchor Links
    // ============================================
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#') return;
            
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                const offset = 80; // Offset for fixed header if you add one
                const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // ============================================
    // Accordion Functionality
    // ============================================
    const accordionTriggers = document.querySelectorAll('.accordion-trigger');
    
    accordionTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const accordionId = this.getAttribute('data-accordion');
            const content = document.getElementById(accordionId);
            const isActive = this.classList.contains('active');
            
            // Close all accordions
            document.querySelectorAll('.accordion-trigger').forEach(t => {
                t.classList.remove('active');
            });
            document.querySelectorAll('.accordion-content').forEach(c => {
                c.classList.remove('active');
            });
            
            // Open clicked accordion if it wasn't active
            if (!isActive) {
                this.classList.add('active');
                content.classList.add('active');
            }
        });
    });

    // ============================================
    // Tabs Functionality (Main Tabs)
    // ============================================
    const tabButtons = document.querySelectorAll('.tab-button');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            const tabsContainer = this.closest('.tabs');
            
            // Remove active class from all buttons in this tabs container
            tabsContainer.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Remove active class from all panels in this tabs container
            tabsContainer.querySelectorAll('.tab-panel').forEach(panel => {
                panel.classList.remove('active');
            });
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Add active class to corresponding panel
            const targetPanel = tabsContainer.querySelector(`#${tabId}`);
            if (targetPanel) {
                targetPanel.classList.add('active');
            }
        });
    });

    // ============================================
    // Dialog Tabs (Sub-tabs in Examples)
    // ============================================
    const dialogTabs = document.querySelectorAll('.dialog-tab');
    
    dialogTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const dialogId = this.getAttribute('data-dialog');
            const dialogContainer = this.closest('.dialog-examples');
            
            // Remove active from all dialog tabs
            dialogContainer.querySelectorAll('.dialog-tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // Remove active from all dialog panels
            dialogContainer.querySelectorAll('.dialog-panel').forEach(p => {
                p.classList.remove('active');
            });
            
            // Add active to clicked tab
            this.classList.add('active');
            
            // Add active to corresponding panel
            const targetPanel = dialogContainer.querySelector(`#${dialogId}`);
            if (targetPanel) {
                targetPanel.classList.add('active');
            }
        });
    });

    // ============================================
    // Scroll Reveal Animation
    // ============================================
    const revealElements = document.querySelectorAll('.block');
    
    const revealOnScroll = () => {
        const windowHeight = window.innerHeight;
        const revealPoint = 100;
        
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            
            if (elementTop < windowHeight - revealPoint) {
                element.classList.add('reveal', 'active');
            }
        });
    };
    
    // Initial check
    revealOnScroll();
    
    // Check on scroll
    window.addEventListener('scroll', revealOnScroll);

    // ============================================
    // Progress Bar Animation
    // ============================================
    const progressBars = document.querySelectorAll('.progress-fill, .reward-progress-fill');
    
    const animateProgressBars = () => {
        progressBars.forEach(bar => {
            const rect = bar.getBoundingClientRect();
            const isVisible = rect.top < window.innerHeight && rect.bottom >= 0;
            
            if (isVisible && !bar.classList.contains('animated')) {
                const width = bar.style.width;
                bar.style.width = '0%';
                
                setTimeout(() => {
                    bar.style.width = width;
                    bar.classList.add('animated');
                }, 100);
            }
        });
    };
    
    window.addEventListener('scroll', animateProgressBars);
    animateProgressBars(); // Initial check

    // ============================================
    // Counter Animation for Stats
    // ============================================
    const animateCounter = (element, target, duration = 2000) => {
        const start = 0;
        const increment = target / (duration / 16);
        let current = start;
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                element.textContent = target.toLocaleString();
                clearInterval(timer);
            } else {
                element.textContent = Math.floor(current).toLocaleString();
            }
        }, 16);
    };
    
    const observeCounters = () => {
        const counters = document.querySelectorAll('.stat-number');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
                    const target = parseFloat(entry.target.textContent);
                    if (!isNaN(target)) {
                        animateCounter(entry.target, target);
                        entry.target.classList.add('counted');
                    }
                }
            });
        }, { threshold: 0.5 });
        
        counters.forEach(counter => observer.observe(counter));
    };
    
    observeCounters();

    // ============================================
    // Social Proof Counter Update
    // ============================================
    const updateSocialProof = () => {
        const socialProofElements = document.querySelectorAll('.social-proof strong');
        
        socialProofElements.forEach(element => {
            let count = parseInt(element.textContent.replace(/,/g, ''));
            
            // Randomly increase by 1-3 every 10-30 seconds
            setInterval(() => {
                count += Math.floor(Math.random() * 3) + 1;
                element.textContent = count.toLocaleString();
            }, (Math.random() * 20000) + 10000);
        });
    };
    
    // Uncomment to enable live counter
    // updateSocialProof();

    // ============================================
    // Lazy Load Images (if you add images later)
    // ============================================
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });
    
    lazyImages.forEach(img => imageObserver.observe(img));

    // ============================================
    // Habit Item Click Animation
    // ============================================
    const habitItems = document.querySelectorAll('.habit-item');
    
    habitItems.forEach(item => {
        item.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 100);
        });
    });

    // ============================================
    // Step Item Hover Effect Enhancement
    // ============================================
    const stepItems = document.querySelectorAll('.step-item');
    
    stepItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 10px 20px rgba(99, 102, 241, 0.2)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.boxShadow = '';
        });
    });

    // ============================================
    // Calendar Day Interactive
    // ============================================
    const calendarDays = document.querySelectorAll('.calendar-day');
    
    calendarDays.forEach(day => {
        day.addEventListener('click', function() {
            if (!this.classList.contains('active')) {
                this.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            }
        });
    });

    // ============================================
    // Quick Button Animations
    // ============================================
    const quickButtons = document.querySelectorAll('.quick-btn');
    
    quickButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Create ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });

    // ============================================
    // Form Submit Handler (if you add forms)
    // ============================================
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Add your form submission logic here
            console.log('Form submitted');
            
            // Example: Show success message
            const successMessage = document.createElement('div');
            successMessage.textContent = 'Спасибо! Мы свяжемся с вами.';
            successMessage.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #10B981;
                color: white;
                padding: 1rem 2rem;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
                z-index: 9999;
                animation: slideIn 0.3s ease;
            `;
            
            document.body.appendChild(successMessage);
            
            setTimeout(() => {
                successMessage.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => successMessage.remove(), 300);
            }, 3000);
        });
    });

    // ============================================
    // Keyboard Navigation for Tabs
    // ============================================
    document.addEventListener('keydown', function(e) {
        const activeTab = document.querySelector('.tab-button.active');
        
        if (!activeTab) return;
        
        const tabsContainer = activeTab.closest('.tabs');
        const allTabs = Array.from(tabsContainer.querySelectorAll('.tab-button'));
        const currentIndex = allTabs.indexOf(activeTab);
        
        if (e.key === 'ArrowRight' && currentIndex < allTabs.length - 1) {
            allTabs[currentIndex + 1].click();
            allTabs[currentIndex + 1].focus();
        } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
            allTabs[currentIndex - 1].click();
            allTabs[currentIndex - 1].focus();
        }
    });

    // ============================================
    // Back to Top Button (optional)
    // ============================================
    const createBackToTop = () => {
        const button = document.createElement('button');
        button.innerHTML = '↑';
        button.className = 'back-to-top';
        button.style.cssText = `
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 48px;
            height: 48px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            font-size: 1.5rem;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
            z-index: 1000;
        `;
        
        document.body.appendChild(button);
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 500) {
                button.style.opacity = '1';
                button.style.visibility = 'visible';
            } else {
                button.style.opacity = '0';
                button.style.visibility = 'hidden';
            }
        });
        
        button.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    };
    
    createBackToTop();

    // ============================================
    // Mobile Menu Toggle (if you add navigation)
    // ============================================
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    if (mobileMenuToggle && mobileMenu) {
        mobileMenuToggle.addEventListener('click', () => {
            mobileMenu.classList.toggle('active');
            mobileMenuToggle.classList.toggle('active');
        });
    }

    // ============================================
    // Testimonial Slider (if you want rotating testimonials)
    // ============================================
    const initTestimonialSlider = () => {
        const testimonials = document.querySelectorAll('.testimonial');
        let currentTestimonial = 0;
        
        if (testimonials.length <= 1) return;
        
        testimonials.forEach((testimonial, index) => {
            if (index !== 0) testimonial.style.display = 'none';
        });
        
        setInterval(() => {
            testimonials[currentTestimonial].style.display = 'none';
            currentTestimonial = (currentTestimonial + 1) % testimonials.length;
            testimonials[currentTestimonial].style.display = 'block';
        }, 5000);
    };
    
    // Uncomment to enable rotating testimonials
    // initTestimonialSlider();

    // ============================================
    // Console Message
    // ============================================
    console.log('%c🚀 OnePercent Landing Page Loaded', 'color: #6366F1; font-size: 16px; font-weight: bold;');
    console.log('%c+1% каждый день', 'color: #10B981; font-size: 12px;');

}); // End DOMContentLoaded

// ============================================
// CSS for Ripple Effect
// ============================================
const rippleStyles = document.createElement('style');
rippleStyles.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(99, 102, 241, 0.5);
        transform: scale(0);
        animation: ripple-animation 0.6s ease-out;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
    
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .back-to-top:hover {
        background: var(--primary-hover);
        transform: translateY(-4px);
        box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4);
    }
    
    .back-to-top:active {
        transform: translateY(-2px);
    }
`;

document.head.appendChild(rippleStyles);
