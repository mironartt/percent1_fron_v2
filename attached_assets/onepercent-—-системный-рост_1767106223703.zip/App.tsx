import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MathSection } from './components/MathSection';
import { Features } from './components/Features';
import { AIMentor } from './components/AIMentor';
import { FinalCTA } from './components/FinalCTA';
import { Testimonials } from './components/Testimonials';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-brand-200 selection:text-brand-900">
      <Header />
      <main>
        <Hero />
        <MathSection />
        <Features />
        <AIMentor />
        <FinalCTA />
        <Testimonials />
        <Pricing />
      </main>
      <Footer />
    </div>
  );
}

export default App;