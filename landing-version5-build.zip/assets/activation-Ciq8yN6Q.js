import{aN as N,r as i,b as n,ae as R}from"./index-TwZwNqi_.js";const m="onepercent_activation",S={select_focus:{onComplete:`Отлично! Ты выбрал фокус на сегодня 🎯

Это первый шаг к продуктивному дню. Теперь у тебя есть ясность, на чём сосредоточиться.

→ **Следующий шаг:** Создай первую привычку в разделе «Привычки»

Маленькие ежедневные действия приводят к большим результатам.`,nextStep:"create_habit"},create_habit:{onComplete:`Привычка создана! 🔥

Привычки — это фундамент изменений. Маленькие действия каждый день создают большие результаты.

→ **Следующий шаг:** Изучи свои цели в разделе «Банк целей»

Посмотри, какие цели AI создал для тебя на основе диагностики.`,nextStep:"view_goals"},view_goals:{onComplete:`Молодец, ты изучил свои цели! 📚

Понимание своих целей — это половина успеха.

→ **Следующий шаг:** Заполни вечернюю рефлексию в разделе «Дневник»

Рефлексия помогает закрепить прогресс и извлечь уроки из дня.`,nextStep:"write_reflection"},write_reflection:{onComplete:`Поздравляю! Ты выполнил все стартовые задания! 🎉

Ты отлично начал свой путь к лучшей версии себя:
✓ Выбрал фокус на день
✓ Создал привычку
✓ Изучил свои цели
✓ Написал рефлексию

Теперь продолжай использовать приложение каждый день. Я буду помогать тебе на каждом шаге.

Помни: всего 1% улучшения каждый день = x37 за год! 📈`,nextStep:null}},g=[{id:"select_focus",title:"Выбери фокус на сегодня",description:"Выбери 1-3 важных шага из своих целей",icon:"Crosshair",xpReward:15,route:"/app/planning"},{id:"create_habit",title:"Создай первую привычку",description:"Добавь полезную привычку для ежедневного выполнения",icon:"Flame",xpReward:15,route:"/app/habits"},{id:"view_goals",title:"Изучи свои цели",description:"Посмотри цели, которые AI создал для тебя",icon:"Target",xpReward:10,route:"/app/goals"},{id:"write_reflection",title:"Заполни вечернюю рефлексию",description:"Запиши свои мысли в дневник",icon:"BookOpen",xpReward:15,route:"/app/journal"}],H=N("activation",()=>{const o=i({}),r=i(!1),a=i(!1),s=i(!1),c=i([]),u=i(null),v=n(()=>g.map(e=>({...e,completed:!!o.value[e.id]}))),p=n(()=>Object.values(o.value).filter(Boolean).length),d=n(()=>g.length),h=n(()=>Math.round(p.value/d.value*100)),f=n(()=>p.value>=d.value),_=n(()=>!(f.value||a.value)),C=n(()=>!(f.value||s.value)),w=n(()=>v.value.find(e=>!e.completed));function x(e){if(!o.value[e]){o.value[e]=!0,l();const t=S[e];return t&&(u.value=t.nextStep,l()),{completed:!0,message:t?.onComplete||null}}return{completed:!1,message:null}}function M(e){return S[e]?.onComplete||null}function I(e){return!!o.value[e]}function G(){r.value=!0,a.value=!0,l()}function T(){r.value=!1}function O(){o.value={},r.value=!1,a.value=!1,s.value=!1,c.value=[],u.value=null,l()}function A(){s.value=!0,a.value=!0,l()}function b(e){c.value.push({...e,timestamp:new Date().toISOString()}),l()}function k(e){u.value=e,l()}function D(){const e=["select_focus","create_habit","view_goals","write_reflection"];for(const t of e)if(!o.value[t])return t;return null}function l(){try{const e={completedTasks:o.value,modalDismissed:r.value,missionStarted:a.value,mentorIntroCompleted:s.value,mentorChatHistory:c.value,currentGuidanceStep:u.value};localStorage.setItem(m,JSON.stringify(e))}catch{}}function E(){try{const e=localStorage.getItem(m);if(e){const t=JSON.parse(e);o.value=t.completedTasks||{},r.value=t.modalDismissed||!1,a.value=t.missionStarted||!1,s.value=t.mentorIntroCompleted||!1,c.value=t.mentorChatHistory||[],u.value=t.currentGuidanceStep||null}}catch{}}function y(){E()}return{tasks:v,completedTasks:o,completedCount:p,totalCount:d,progress:h,isAllCompleted:f,shouldShowMission:_,shouldShowMentorSpotlight:C,nextTask:w,modalDismissed:r,missionStarted:a,mentorIntroCompleted:s,mentorChatHistory:c,currentGuidanceStep:u,completeTask:x,getGuidanceMessage:M,isTaskCompleted:I,dismissModal:G,showModal:T,resetMission:O,completeMentorIntro:A,addMentorChatMessage:b,setGuidanceStep:k,getNextGuidanceStep:D,init:y}});export{H as useActivationStore};
