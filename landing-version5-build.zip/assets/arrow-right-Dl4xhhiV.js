import{c as r}from"./index-TwZwNqi_.js";const a=r("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);export{a as A};
