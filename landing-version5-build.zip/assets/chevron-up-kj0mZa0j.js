import{c as e}from"./index-TwZwNqi_.js";const c=e("chevron-up",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);export{c as C};
